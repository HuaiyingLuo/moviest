package com.hyluo.moviest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviestApplication.class, args);
	}

}
